# Monowave

An original Android music player prototype inspired by the architecture of [NØTE](https://github.com/SJbuilds04/NOTE). It has its own interface and app code. The external stream resolver is [NewPipe Extractor](https://github.com/TeamNewPipe/NewPipeExtractor) v0.26.5, not Google's MediaPipe. This project is neither an official NØTE fork nor affiliated with NewPipe or YouTube.

## Features

- Search YouTube Music's unofficial web interface for songs, artists, albums, and playlists.
- Open artist, album, or playlist pages and play available tracks.
- Android audio playback with background notification, lock screen controls, seek, queue, shuffle, and repeat.
- Locally stored likes, custom playlists, public playlist import, listening history, and queue.
- No account or server operated by Monowave. Playback streams are fetched from their host and never saved as audio files.

**Implementation:** `src/music.ts` handles discovery; `modules/stream-extractor` is an Android Expo module linking NewPipe Extractor. The module resolves a video ID to a progressive audio URL. `src/useMonowave.ts` passes that URL and the matching User-Agent to `expo-audio`; it manages queue and local persistence. `src/App.tsx` implements the interface.

## Build setup

The project uses Expo SDK 57, React Native 0.86.3, and the Node version in `.nvmrc`. Direct package versions are pinned and `package-lock.json` is included. Use `npm ci` to install the locked dependency tree.

The local extractor has package metadata and an explicit autolinking path. The ignore files exclude only the generated root `/android/` project; they preserve `modules/stream-extractor/android/` for cloud builds.

### Cloud APK build — no local Android SDK needed

Install Node.js 24.19.0 (or use `nvm use`), then run these commands from the extracted project folder:

```bash
npm ci
npm run check
npx eas-cli@latest login
npx eas-cli@latest init
npm run build:apk
```

Sign into your Expo account. During `init`, create or select your project; the CLI writes its real project ID to the app configuration. Follow the Android signing prompts for your own app. The `preview` profile builds an installable APK with its JavaScript bundled. When the cloud build completes, EAS supplies the download link. No cloud build was submitted during this reconfiguration.

### Local Android development

Install JDK 17+, Android Studio, and the Android SDK. Configure `ANDROID_HOME`, then connect a device or start an emulator:

```bash
npm ci
npm run prebuild:android
npm run android
```

The Kotlin extractor requires a native development build and is unavailable in Expo Go. `npm start` starts Metro for a development client. `npm run build:development` builds that client in the cloud. `npm run build:aab` selects the production Android App Bundle profile; it does not publish the app.

The Android package ID is currently `com.example.monowaveplayer`. Choose your own identifier in `app.json` before creating a production release. `android.versionCode` is managed locally in that file.

### Verification

- TypeScript: passed.
- Native autolinking: extractor detected with its Kotlin class.
- Clean Android prebuild: passed.
- Android JavaScript/Hermes export: passed (608 modules).
- Dependency versions: matched against the installed Expo SDK's bundled compatibility map in offline mode.
- Ignore rules: verified to preserve native module source and the lockfile.

See `BUILD-STATUS.md` for exact checks and limits. Native Gradle/Kotlin compilation and device playback remain untested because this workspace lacks the Android SDK. YouTube's unofficial interface can change and restricted tracks may fail to play.

### Useful commands

| Command | Purpose |
| --- | --- |
| `npm run check` | Type-check app code |
| `npm run check:dependencies` | Check Expo package compatibility |
| `npm run check:native` | Inspect native autolinking |
| `npm run export:android` | Bundle JavaScript for Android |
| `npm run build:apk` | Start an EAS preview APK build |

Build configuration follows [Expo APK profiles](https://docs.expo.dev/build-reference/apk/), [EAS configuration](https://docs.expo.dev/build/eas-json/), and [Expo autolinking](https://docs.expo.dev/modules/autolinking/).

## License

The app source is GPL-3.0-or-later because it links the GPL-3.0-or-later NewPipe Extractor. It fetches that external dependency during Android compilation. See [the GNU license](https://www.gnu.org/licenses/gpl-3.0.html) and the [NewPipe repository](https://github.com/TeamNewPipe/NewPipeExtractor). When distributing a binary, include the full license text, dependency notices, and matching source. Respect the terms and rights that apply to the content you play.
