import React, { useCallback, useState } from 'react';
import { Image, Linking, Modal, Pressable, ScrollView, StyleSheet, Text, TextInput, View } from 'react-native';
import { SafeAreaProvider, SafeAreaView } from 'react-native-safe-area-context';
import { StatusBar } from 'expo-status-bar';
import { browseMusic, parseLink, searchMusic, trackById } from './music';
import type { SearchItem, Track } from './music';
import { useMonowave } from './useMonowave';

type Tab = 'home' | 'search' | 'library' | 'history' | 'settings' | 'player' | 'collection' | 'playlist';
type Filter = 'all' | SearchItem['kind'];
const C = { bg: '#0D0B16', panel: '#221D35', card: '#171326', text: '#F8F6FF', muted: '#AFA6C4', accent: '#A58BFF', line: '#38314D' };

function Artwork({ uri, size = 52 }: { uri?: string; size?: number }) {
  return uri ? <Image source={{ uri }} style={{ width: size, height: size, borderRadius: 10 }} /> :
    <View style={[styles.emptyArt, { width: size, height: size }]}><Text style={{ color: C.accent, fontSize: size / 3 }}>♫</Text></View>;
}
function Action({ label, onPress, active = false }: { label: string; onPress: () => void; active?: boolean }) {
  return <Pressable onPress={onPress} style={[styles.action, active && styles.actionActive]}>
    <Text style={[styles.actionText, active && { color: C.bg }]}>{label}</Text>
  </Pressable>;
}
function Heading({ title, detail }: { title: string; detail?: string }) {
  return <View style={styles.heading}><Text style={styles.headingText}>{title}</Text>{detail ? <Text style={styles.muted}>{detail}</Text> : null}</View>;
}
function TrackLine({ track, onPress, onMore, trailing }: { track: Track; onPress: () => void; onMore?: () => void; trailing?: string }) {
  return <View style={styles.line}>
    <Pressable style={styles.lineMain} onPress={onPress}><Artwork uri={track.cover} />
      <View style={styles.lineText}><Text numberOfLines={1} style={styles.lineTitle}>{track.title}</Text>
        <Text numberOfLines={1} style={styles.muted}>{track.artist}</Text></View></Pressable>
    {onMore ? <Pressable hitSlop={12} onPress={onMore}><Text style={styles.ellipsis}>{trailing ?? '⋯'}</Text></Pressable> : null}
  </View>;
}

function Content() {
  const app = useMonowave();
  const { data, current } = app;
  const [tab, setTab] = useState<Tab>('home');
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<SearchItem[]>([]);
  const [filter, setFilter] = useState<Filter>('all');
  const [pending, setPending] = useState(false);
  const [error, setError] = useState('');
  const [collection, setCollection] = useState<SearchItem | null>(null);
  const [children, setChildren] = useState<SearchItem[]>([]);
  const [playlistId, setPlaylistId] = useState('');
  const [actionTrack, setActionTrack] = useState<Track | null>(null);
  const [newList, setNewList] = useState('');
  const [importText, setImportText] = useState('');
  const [barWidth, setBarWidth] = useState(1);

  const find = useCallback(async (term: string) => {
    if (!term.trim()) return;
    setPending(true); setError(''); setTab('search');
    try { setResults(await searchMusic(term.trim())); }
    catch (e) { setError(`Search failed: ${String(e)}`); }
    finally { setPending(false); }
  }, []);

  const openCollection = useCallback(async (item: SearchItem) => {
    setCollection(item); setChildren([]); setTab('collection'); setPending(true); setError('');
    try { setChildren(await browseMusic(item.id)); }
    catch (e) { setError(`Could not open ${item.title}: ${String(e)}`); }
    finally { setPending(false); }
  }, []);

  const importLink = useCallback(async () => {
    const link = parseLink(importText);
    if (!link) { setError('Paste a YouTube Music track or playlist link.'); return; }
    setPending(true); setError('');
    try {
      if (link.kind === 'track') app.playTrack(await trackById(link.id));
      else {
        const imported = (await browseMusic(link.id)).flatMap(item => item.track ? [item.track] : []);
        if (!imported.length) throw new Error('No tracks found in this playlist');
        app.createPlaylist(`Imported · ${link.id}`, imported);
        setTab('library');
      }
      setImportText('');
    } catch (e) { setError(`Import failed: ${String(e)}`); }
    finally { setPending(false); }
  }, [importText, app]);

  const chosen = data.playlists.find(list => list.id === playlistId);
  const tracksInCollection = children.flatMap(item => item.track ? [item.track] : []);
  const playFrom = (track: Track, tracks?: Track[]) => { app.playTrack(track, tracks); setTab('player'); };
  const collectionKind = collection?.kind === 'artist' ? 'artist' : collection?.kind === 'album' ? 'album' : 'playlist';

  return <SafeAreaView style={styles.page} edges={['top', 'bottom']}>
    <StatusBar style="light" />
    <View style={styles.topBar}>
      <Pressable onPress={() => setTab('home')}><Text style={styles.brand}>◉  MONOWAVE</Text></Pressable>
      <Pressable onPress={() => setTab(tab === 'settings' ? 'home' : 'settings')}><Text style={styles.topIcon}>⚙</Text></Pressable>
    </View>
    {(error || app.message) ? <Pressable onPress={() => setError('')} style={styles.error}><Text style={styles.errorText}>{error || app.message}</Text></Pressable> : null}
    <ScrollView keyboardShouldPersistTaps="handled" contentContainerStyle={styles.scroll} key={tab}>
      {tab === 'home' && <>
        <Text style={styles.kicker}>YOUR LISTENING SPACE</Text>
        <Text style={styles.hero}>Good to see you{data.name ? `, ${data.name}` : ''}.</Text>
        <Text style={styles.muted}>Search, save, and play the music you choose.</Text>
        <View style={styles.heroCard}>
          <Text style={styles.cardTitle}>Find something new</Text>
          <Text style={styles.muted}>Search tracks, albums, artists, and playlists.</Text>
          <View style={styles.inline}><TextInput value={query} onChangeText={setQuery}
            onSubmitEditing={() => void find(query)} placeholder="Song or artist" placeholderTextColor={C.muted}
            style={[styles.input, { flex: 1 }]} returnKeyType="search" />
            <Action label="Go" onPress={() => void find(query)} active /></View>
        </View>
        <Heading title="Recently played" detail={`${data.history.length} listens`} />
        {data.history.slice(0, 5).map((entry, index) => <TrackLine key={`${entry.playedAt}:${index}`} track={entry.track}
          onPress={() => playFrom(entry.track)} onMore={() => setActionTrack(entry.track)} />)}
        {!data.history.length && <Text style={styles.placeholder}>Your recent tracks appear here after you play one.</Text>}
        <Heading title="Liked tracks" detail={`${data.liked.length} saved`} />
        {data.liked.slice(0, 4).map(track => <TrackLine key={track.id} track={track}
          onPress={() => playFrom(track, data.liked)} onMore={() => setActionTrack(track)} />)}
      </>}

      {tab === 'search' && <>
        <Heading title="Search" detail="YouTube Music" />
        <View style={styles.inline}><TextInput value={query} onChangeText={setQuery}
          onSubmitEditing={() => void find(query)} placeholder="What do you want to hear?"
          placeholderTextColor={C.muted} style={[styles.input, { flex: 1 }]} returnKeyType="search" />
          <Action label="Search" active onPress={() => void find(query)} /></View>
        <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ marginTop: 18 }}>
          {(['all', 'track', 'album', 'artist', 'playlist'] as Filter[]).map(value =>
            <Action key={value} label={value === 'track' ? 'Songs' : value[0].toUpperCase() + value.slice(1)}
              active={filter === value} onPress={() => setFilter(value)} />)}
        </ScrollView>
        {pending && <Text style={styles.placeholder}>Loading…</Text>}
        {results.filter(item => filter === 'all' || item.kind === filter).map(item =>
          <TrackLine key={`${item.kind}:${item.id}`} track={item.track ?? { id: item.id, title: item.title, artist: item.subtitle, cover: item.cover }}
            onPress={() => item.track ? playFrom(item.track) : void openCollection(item)}
            onMore={item.track ? () => setActionTrack(item.track!) : undefined} trailing={item.kind === 'track' ? undefined : '›'} />)}
        {!pending && !results.length && <Text style={styles.placeholder}>Enter a search above to explore music.</Text>}
      </>}

      {tab === 'collection' && <>
        <Action label="‹ Back to search" onPress={() => setTab('search')} />
        <View style={styles.collectionHeader}><Artwork uri={collection?.cover} size={112} />
          <View style={{ flex: 1 }}><Text style={styles.kicker}>{collectionKind.toUpperCase()}</Text>
            <Text style={styles.headingText}>{collection?.title}</Text>
            <Text style={styles.muted}>{collection?.subtitle}</Text></View></View>
        {!!tracksInCollection.length && <Action label="▶ Play all" active onPress={() => playFrom(tracksInCollection[0], tracksInCollection)} />}
        {pending && <Text style={styles.placeholder}>Loading…</Text>}
        {children.map(item => <TrackLine key={`${item.kind}:${item.id}`} track={item.track ??
          { id: item.id, title: item.title, artist: item.subtitle, cover: item.cover }}
          onPress={() => item.track ? playFrom(item.track, tracksInCollection) : void openCollection(item)}
          onMore={item.track ? () => setActionTrack(item.track!) : undefined} />)}
      </>}

      {tab === 'library' && <>
        <Heading title="Your library" detail="Saved on this device" />
        <Heading title="Liked songs" detail={`${data.liked.length}`} />
        {data.liked.map(track => <TrackLine key={track.id} track={track} onPress={() => playFrom(track, data.liked)} onMore={() => setActionTrack(track)} />)}
        <Heading title="Playlists" detail={`${data.playlists.length}`} />
        <View style={styles.inline}><TextInput value={newList} onChangeText={setNewList} placeholder="New playlist name"
          placeholderTextColor={C.muted} style={[styles.input, { flex: 1 }]} />
          <Action label="Create" active onPress={() => { if (newList.trim()) { app.createPlaylist(newList); setNewList(''); } }} /></View>
        {data.playlists.map(list => <Pressable key={list.id} style={styles.listCard} onPress={() => { setPlaylistId(list.id); setTab('playlist'); }}>
          <Text style={styles.cardTitle}>{list.name}</Text><Text style={styles.muted}>{list.tracks.length} tracks  ›</Text></Pressable>)}
        <Heading title="Import a public playlist" />
        <TextInput value={importText} onChangeText={setImportText} autoCapitalize="none"
          placeholder="Paste a YouTube Music link" placeholderTextColor={C.muted} style={styles.input} />
        <Action label={pending ? 'Loading…' : 'Import link'} onPress={() => void importLink()} />
      </>}

      {tab === 'playlist' && <>
        <Action label="‹ Library" onPress={() => setTab('library')} />
        <Heading title={chosen?.name ?? 'Playlist'} detail={`${chosen?.tracks.length ?? 0} tracks`} />
        {!!chosen?.tracks.length && <Action label="▶ Play playlist" active onPress={() => playFrom(chosen.tracks[0], chosen.tracks)} />}
        {chosen?.tracks.map(track => <TrackLine key={track.id} track={track} onPress={() => playFrom(track, chosen.tracks)}
          onMore={() => app.removeFromPlaylist(chosen.id, track.id)} trailing="×" />)}
        <Action label="Delete playlist" onPress={() => { app.deletePlaylist(playlistId); setTab('library'); }} />
      </>}

      {tab === 'history' && <>
        <Heading title="History" detail={`${data.history.length} listens`} />
        {data.history.map((entry, index) => <TrackLine key={`${entry.playedAt}:${index}`} track={entry.track}
          onPress={() => playFrom(entry.track)} onMore={() => setActionTrack(entry.track)} />)}
        {!data.history.length && <Text style={styles.placeholder}>Your listening history is empty.</Text>}
        {!!data.history.length && <Action label="Clear history" onPress={app.clearHistory} />}
      </>}

      {tab === 'player' && <>
        <Action label="‹ Back" onPress={() => setTab('home')} />
        <View style={styles.playerArt}><Artwork uri={current?.cover} size={220} /></View>
        <Text style={styles.playerTitle} numberOfLines={2}>{current?.title ?? 'Nothing playing'}</Text>
        <Text style={[styles.muted, { textAlign: 'center' }]}>{current?.artist}</Text>
        <View onLayout={event => setBarWidth(event.nativeEvent.layout.width)} style={styles.progressArea}>
          <Pressable style={styles.progress} onPress={event => app.seek((event.nativeEvent.locationX / barWidth) * app.duration)}>
            <View style={[styles.progressFill, { width: `${Math.min(100, app.duration ? app.position / app.duration * 100 : 0)}%` }]} />
          </Pressable><View style={styles.progressLabels}><Text style={styles.muted}>{formatTime(app.position)}</Text>
            <Text style={styles.muted}>{formatTime(app.duration || current?.duration || 0)}</Text></View></View>
        <View style={styles.controls}>
          <Action label={data.shuffle ? 'Shuffle ✓' : 'Shuffle'} onPress={app.toggleShuffle} />
          <Action label="⏮" onPress={app.previous} />
          <Action label={app.busy ? '…' : app.playing ? '❚❚' : '▶'} active onPress={app.toggle} />
          <Action label="⏭" onPress={app.next} />
          <Action label={`Repeat ${data.repeat}`} onPress={app.cycleRepeat} />
        </View>
        {!!current && <Action label={data.liked.some(t => t.id === current.id) ? '♥ Liked' : '♡ Like'}
          onPress={() => app.like(current)} />}
        <Heading title="Up next" detail={`${data.queue.length} in queue`} />
        {data.queue.map((track, index) => <View key={`${track.id}:${index}`} style={styles.queueLine}>
          <Text style={{ color: index === data.index ? C.accent : C.muted, width: 23 }}>{index === data.index ? '♪' : index + 1}</Text>
          <Pressable style={{ flex: 1 }} onPress={() => void app.playAt(data.queue, index)}><Text numberOfLines={1} style={styles.lineTitle}>{track.title}</Text></Pressable>
          <Pressable onPress={() => app.moveQueued(index, index - 1)}><Text style={styles.smallControl}>↑</Text></Pressable>
          <Pressable onPress={() => app.moveQueued(index, index + 1)}><Text style={styles.smallControl}>↓</Text></Pressable>
          <Pressable onPress={() => app.removeQueued(index)}><Text style={styles.smallControl}>×</Text></Pressable>
        </View>)}
      </>}

      {tab === 'settings' && <>
        <Heading title="Settings" />
        <Text style={styles.kicker}>DISPLAY NAME</Text>
        <TextInput value={data.name} onChangeText={app.setName} placeholder="Optional name"
          placeholderTextColor={C.muted} style={styles.input} maxLength={40} />
        <Heading title="About Monowave" />
        <Text style={styles.body}>Monowave stores likes, playlists, queue, and history locally. It uses the Android NewPipe Extractor module to obtain playable streams for videos you select. Streaming needs internet access. The app does not save audio files.</Text>
        <Text style={styles.body}>Search uses YouTube Music's unofficial web interface. Playback availability can change when that service changes, or when a track is restricted.</Text>
        <Action label="NewPipe Extractor source" onPress={() => void Linking.openURL('https://github.com/TeamNewPipe/NewPipeExtractor')} />
        <Action label="NØTE reference project" onPress={() => void Linking.openURL('https://github.com/SJbuilds04/NOTE')} />
        <Action label="GPL-3.0 license" onPress={() => void Linking.openURL('https://www.gnu.org/licenses/gpl-3.0.html')} />
      </>}
    </ScrollView>

    {current && tab !== 'player' && <Pressable style={styles.mini} onPress={() => setTab('player')}>
      <Artwork uri={current.cover} size={40} /><View style={{ flex: 1 }}><Text numberOfLines={1} style={styles.lineTitle}>{current.title}</Text>
        <Text numberOfLines={1} style={styles.muted}>{current.artist}</Text></View>
      <Pressable onPress={app.toggle} style={{ padding: 12 }}><Text style={styles.lineTitle}>{app.playing ? '❚❚' : '▶'}</Text></Pressable>
    </Pressable>}
    <View style={styles.tabbar}>
      {(['home', 'search', 'library', 'history'] as Tab[]).map(value => <Pressable key={value}
        style={styles.tab} onPress={() => setTab(value)}><Text style={{ color: tab === value ? C.accent : C.muted, fontWeight: '700' }}>
          {value === 'home' ? '⌂' : value === 'search' ? '⌕' : value === 'library' ? '♫' : '◷'}  {value}</Text></Pressable>)}
    </View>

    <Modal visible={!!actionTrack} transparent animationType="slide" onRequestClose={() => setActionTrack(null)}>
      <Pressable style={styles.overlay} onPress={() => setActionTrack(null)}>
        <Pressable style={styles.sheet} onPress={event => event.stopPropagation()}>
          <Heading title={actionTrack?.title ?? ''} detail={actionTrack?.artist} />
          {actionTrack && <>
            <Action label="Play now" active onPress={() => { playFrom(actionTrack); setActionTrack(null); }} />
            <Action label="Play next" onPress={() => { app.addNext(actionTrack); setActionTrack(null); }} />
            <Action label="Add to queue" onPress={() => { app.enqueue(actionTrack); setActionTrack(null); }} />
            <Action label={data.liked.some(t => t.id === actionTrack.id) ? 'Unlike' : 'Like'}
              onPress={() => { app.like(actionTrack); setActionTrack(null); }} />
            {data.playlists.map(list => <Action key={list.id} label={`Add to ${list.name}`} onPress={() => {
              app.addToPlaylist(list.id, actionTrack); setActionTrack(null);
            }} />)}
          </>}
          <Action label="Close" onPress={() => setActionTrack(null)} />
        </Pressable>
      </Pressable>
    </Modal>
  </SafeAreaView>;
}
function formatTime(value: number) { const n = Math.max(0, Math.floor(value)); return `${Math.floor(n / 60)}:${String(n % 60).padStart(2, '0')}`; }
export default function App() { return <SafeAreaProvider><Content /></SafeAreaProvider>; }

const styles = StyleSheet.create({
  page: { flex: 1, backgroundColor: C.bg },
  topBar: { height: 55, paddingHorizontal: 20, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  brand: { color: C.accent, fontWeight: '900', letterSpacing: 2, fontSize: 15 },
  topIcon: { color: C.text, fontSize: 22 },
  scroll: { padding: 20, paddingBottom: 35, gap: 10 },
  kicker: { color: C.accent, fontSize: 11, letterSpacing: 2, fontWeight: '800' },
  hero: { color: C.text, fontSize: 32, fontWeight: '800', marginTop: 7, marginBottom: 5 },
  heroCard: { backgroundColor: C.panel, padding: 18, borderRadius: 20, marginTop: 24, gap: 8 },
  cardTitle: { color: C.text, fontSize: 18, fontWeight: '700' },
  muted: { color: C.muted, fontSize: 13 },
  inline: { flexDirection: 'row', alignItems: 'center', gap: 8, marginTop: 7 },
  input: { backgroundColor: C.card, color: C.text, borderColor: C.line, borderWidth: 1, borderRadius: 12, padding: 13, fontSize: 15 },
  heading: { marginTop: 18, marginBottom: 8, gap: 2 },
  headingText: { color: C.text, fontSize: 23, fontWeight: '800' },
  action: { alignSelf: 'flex-start', backgroundColor: C.panel, borderColor: C.line, borderWidth: 1, paddingHorizontal: 13, paddingVertical: 11, borderRadius: 12, marginRight: 7, marginBottom: 7 },
  actionActive: { backgroundColor: C.accent, borderColor: C.accent },
  actionText: { color: C.text, fontSize: 13, fontWeight: '700' },
  line: { flexDirection: 'row', alignItems: 'center', minHeight: 62, borderBottomColor: C.line, borderBottomWidth: StyleSheet.hairlineWidth },
  lineMain: { flex: 1, flexDirection: 'row', alignItems: 'center', gap: 12 },
  lineText: { flex: 1, gap: 3 },
  lineTitle: { color: C.text, fontSize: 14, fontWeight: '600' },
  ellipsis: { color: C.muted, fontSize: 24, paddingHorizontal: 8 },
  emptyArt: { backgroundColor: C.panel, borderRadius: 10, alignItems: 'center', justifyContent: 'center' },
  placeholder: { color: C.muted, marginTop: 20, marginBottom: 15, lineHeight: 21 },
  collectionHeader: { flexDirection: 'row', gap: 18, alignItems: 'center', paddingVertical: 25 },
  listCard: { backgroundColor: C.panel, padding: 17, borderRadius: 15, gap: 4, marginBottom: 5 },
  playerArt: { alignItems: 'center', marginVertical: 24 },
  playerTitle: { color: C.text, fontWeight: '800', fontSize: 26, textAlign: 'center' },
  progressArea: { marginTop: 28 },
  progress: { height: 18, backgroundColor: C.panel, borderRadius: 9, justifyContent: 'center', overflow: 'hidden' },
  progressFill: { backgroundColor: C.accent, height: 18 },
  progressLabels: { flexDirection: 'row', justifyContent: 'space-between', marginTop: 8 },
  controls: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', flexWrap: 'wrap', marginVertical: 22 },
  queueLine: { flexDirection: 'row', alignItems: 'center', gap: 5, paddingVertical: 11, borderBottomColor: C.line, borderBottomWidth: StyleSheet.hairlineWidth },
  smallControl: { color: C.accent, fontSize: 18, paddingHorizontal: 7 },
  body: { color: C.muted, fontSize: 14, lineHeight: 22, marginBottom: 9 },
  mini: { flexDirection: 'row', alignItems: 'center', backgroundColor: C.panel, paddingHorizontal: 12, paddingVertical: 5, gap: 11, marginHorizontal: 9, borderRadius: 12 },
  tabbar: { flexDirection: 'row', paddingVertical: 12, borderTopColor: C.line, borderTopWidth: 1 },
  tab: { flex: 1, alignItems: 'center' },
  error: { backgroundColor: '#4C263B', padding: 10, marginHorizontal: 13, borderRadius: 8 },
  errorText: { color: C.text },
  overlay: { flex: 1, justifyContent: 'flex-end', backgroundColor: '#0009' },
  sheet: { backgroundColor: C.card, borderTopLeftRadius: 22, borderTopRightRadius: 22, padding: 22, maxHeight: '85%' },
});
